package com.example.fblaapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import org.w3c.dom.NameList;
import org.w3c.dom.Text;
import java.util.Random;

import java.util.ArrayList;
import java.util.HashMap;

public class TeacherHome extends AppCompatActivity {
    final static int REQUEST_CODE = 1232;
    Button viewStudents, viewAttendance, createEvent, viewAndEditPrizes, viewAndEditLeaderboard, generateReport, viewAndEditEvents, signOut, help, export;
    TextView tv1, NinthGradeStats, TenthGradeStats, EleventhGradeStats, TwelfthGradeStats, NinthGradeWinner, TenthGradeWinner, EleventhGradeWinner, TwelfthGradeWinner, NinthGradeWinnerStats, TenthGradeWinnerStats, EleventhGradeWinnerStats, TwelfthGradeWinnerStats, NinthGradeRandom, TenthGradeRandom, EleventhGradeRandom, TwelfthGradeRandom;
    ArrayList<String> NameLst;
    ArrayList<Integer> PointsLst;
    HashMap<String, Integer> prizes;
    DatabaseHelper DB;
    Random random;
    String username;
    Bundle b;
    private AlertDialog.Builder dialogBuilder, confirmBuilder;
    private AlertDialog dialog, confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_home);
        askPermissions();
        NameLst = new ArrayList<String>();
        random = new Random();
        PointsLst = new ArrayList<Integer>();
        prizes = new HashMap<String, Integer>();
        prizes.put("Homework Pass", 300);
        prizes.put("Principal for the Day", 3000);
        prizes.put("Pizza Party", 500);
        prizes.put("In-N-Out Food Truck", 10000);
        prizes.put("Class Sticker", 50);
        prizes.put("School Hoodie", 2000);
        b = getIntent().getExtras();
        String username = b.getString("username");
        viewStudents = findViewById(R.id.ViewStudents);
        viewAttendance = findViewById(R.id.ViewAttendance);
        createEvent = findViewById(R.id.CreateEvent);
        viewAndEditPrizes = findViewById(R.id.ViewAndEditPrizes);
        viewAndEditLeaderboard = findViewById(R.id.ViewAndEditLeaderboard);
        generateReport = findViewById(R.id.GenerateReport);
        viewAndEditEvents = findViewById(R.id.ViewAndEditEvents);
        help = findViewById(R.id.Help);
        DB = new DatabaseHelper(this);
        signOut = findViewById(R.id.SignOut);
        tv1 = findViewById(R.id.TV1);
        String name = DB.getDataName(username);
        Log.d("the name is",name);
        tv1.setText("Hi " + name.split("\\s+")[0] + "!👋");
        viewStudents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ViewStudents = new Intent(TeacherHome.this, ViewStudents.class);
                ViewStudents.putExtra("code", name.split("\\s+")[2]);
                ViewStudents.putExtra("username",username);
                startActivity(ViewStudents);

            }
        });
        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainPage = new Intent(TeacherHome.this, MainActivity.class);
                startActivity(mainPage);
            }
        });
        createEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainPage = new Intent(TeacherHome.this, CreateEvent.class);
                startActivity(mainPage);
            }
        });
        viewAndEditPrizes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewPrize = new Intent(TeacherHome.this, ViewPrizes.class);
                startActivity(viewPrize);
            }
        });
        viewAndEditLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewLeaderboard = new Intent(TeacherHome.this, ViewLeaderboard.class);
                startActivity(viewLeaderboard);
            }
        });
        viewAndEditEvents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewEvents = new Intent(TeacherHome.this, ViewEvents.class);
                startActivity(viewEvents);
            }
        });
        generateReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });
        viewAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewAttendance = new Intent(TeacherHome.this, ViewAttendance.class);
                viewAttendance.putExtras(b);
                startActivity(viewAttendance);
            }
        });
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent help = new Intent(TeacherHome.this, Help.class);
                startActivity(help);
            }
        });


    }
    private void confirmDialog(){
        confirmBuilder = new AlertDialog.Builder(this,R.style.AlertDialogCustom);
        final View confirmView = getLayoutInflater().inflate(R.layout.confirm,null);
        confirmBuilder.setView(confirmView);
        confirm = confirmBuilder.create();
        confirm.requestWindowFeature(Window.FEATURE_NO_TITLE);
        confirm.show();
        Button yes = confirmView.findViewById(R.id.yes);
        Button no = confirmView.findViewById(R.id.no);
        yes.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                createNewDialog();
                confirm.dismiss();
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirm.dismiss();
            }
        });
    }
    private void createNewDialog() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View popupView = getLayoutInflater().inflate(R.layout.popup, null);
        export = popupView.findViewById(R.id.ExportButton);
        NinthGradeStats = popupView.findViewById(R.id.NinthGradeStats);
        NinthGradeWinner = popupView.findViewById(R.id.NinthGradeWinner);
        NinthGradeWinnerStats = popupView.findViewById(R.id.NinthGradeWinnerPoints);
        NinthGradeRandom = popupView.findViewById(R.id.NinthGradeRandom);
        TenthGradeStats = popupView.findViewById(R.id.TenthGradeStats);
        TenthGradeWinner = popupView.findViewById(R.id.TenthGradeWinner);
        TenthGradeWinnerStats = popupView.findViewById(R.id.TenthGradeWinnerPoints);
        TenthGradeRandom = popupView.findViewById(R.id.TenthGradeRandom);
        EleventhGradeStats = popupView.findViewById(R.id.EleventhGradeStats);
        EleventhGradeWinner = popupView.findViewById(R.id.EleventhGradeWinner);
        EleventhGradeWinnerStats = popupView.findViewById(R.id.EleventhGradeWinnerPoints);
        EleventhGradeRandom = popupView.findViewById(R.id.EleventhGradeRandom);
        TwelfthGradeStats = popupView.findViewById(R.id.TwelfthGradeStats);
        TwelfthGradeWinner = popupView.findViewById(R.id.TwelfthGradeWinner);
        TwelfthGradeWinnerStats = popupView.findViewById(R.id.TwelfthGradeWinnerPoints);
        TwelfthGradeRandom = popupView.findViewById(R.id.TwelfthGradeRandom);
        storeDataInArrays("9");
        if(NameLst.size()>0) {
            int randomIndex9 = random.nextInt(NameLst.size());
            NinthGradeStats.setText(NameLst.size() + " students, avg. points per student: " + getAverage());
            NinthGradeWinner.setText("9th Grade - " + getNameofHighestPoints());
            NinthGradeWinnerStats.setText(("Based on " + getNameofHighestPoints() + "'s points, they have earned: " + getPrizes(getHighestPoints())).replaceAll(", $",""));
            NinthGradeRandom.setText("9th - " + NameLst.get(randomIndex9) + " has won " + getPrizes(PointsLst.get(randomIndex9)).replaceAll(", $","") + "!");
            clearArrays();
        }
        else{
            NinthGradeStats.setText("0 students, avg. points per student: 0");
            NinthGradeWinner.setText("9th Grade - N/A");
            NinthGradeWinnerStats.setText("N/A");
            NinthGradeRandom.setText("9th - N/A");
        }
        storeDataInArrays("10");
        if(NameLst.size()>0) {
            int randomIndex10 = random.nextInt(NameLst.size());
            TenthGradeStats.setText(NameLst.size() + " students, avg. points per student: " + getAverage());
            TenthGradeWinner.setText("10th Grade - " + getNameofHighestPoints());
            TenthGradeWinnerStats.setText(("Based on " + getNameofHighestPoints() + "'s points, they have earned: " + getPrizes(getHighestPoints())).replaceAll(", $",""));
            TenthGradeRandom.setText("10th - " + NameLst.get(randomIndex10) + " has won " + getPrizes(PointsLst.get(randomIndex10)).replaceAll(", $","") + "!");
            clearArrays();
        }
        else{
            TenthGradeStats.setText("0 students, avg. points per student: 0");
            TenthGradeWinner.setText("10th Grade - N/A");
            TenthGradeWinnerStats.setText("N/A");
            TenthGradeRandom.setText("10th - N/A");
        }
        storeDataInArrays("11");
        if(NameLst.size()>0) {
            int randomIndex11 = random.nextInt(NameLst.size());
            EleventhGradeStats.setText(NameLst.size() + " students, avg. points per student: " + getAverage());
            EleventhGradeWinner.setText("11th Grade - " + getNameofHighestPoints());
            EleventhGradeWinnerStats.setText(("Based on " + getNameofHighestPoints() + "'s points, they have earned: " + getPrizes(getHighestPoints())).replaceAll(", $",""));
            EleventhGradeRandom.setText("11th - " + NameLst.get(randomIndex11) + " has won " + getPrizes(PointsLst.get(randomIndex11)).replaceAll(", $","") + "!");
            clearArrays();
        }
        else{
            EleventhGradeStats.setText("0 students, avg. points per student: 0");
            EleventhGradeWinner.setText("11th Grade - N/A");
            EleventhGradeWinnerStats.setText("N/A");
            EleventhGradeRandom.setText("11th - N/A");
        }
        storeDataInArrays("12");
        if(NameLst.size()>0) {
            int randomIndex12 = random.nextInt(NameLst.size());
            TwelfthGradeStats.setText(NameLst.size() + " students, avg. points per student: " + getAverage());
            TwelfthGradeWinner.setText("12th Grade - " + getNameofHighestPoints());
            String output = "Based on " + getNameofHighestPoints() + "'s points, they have earned: " + getPrizes(getHighestPoints());
            TwelfthGradeWinnerStats.setText(output.replaceAll(", $",""));
            TwelfthGradeRandom.setText("12th - " + NameLst.get(randomIndex12) + " has won " + getPrizes(PointsLst.get(randomIndex12)).replaceAll(", $","") + "!");
            clearArrays();
        }
        else{
            TwelfthGradeStats.setText("0 students, avg. points per student: 0");
            TwelfthGradeWinner.setText("12th Grade - N/A");
            TwelfthGradeWinnerStats.setText("N/A");
            TwelfthGradeRandom.setText("12th - N/A");
        }
        dialogBuilder.setView(popupView);
        dialog = dialogBuilder.create();
        dialog.show();
        export.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                convertXMLtoPDF(popupView);
                dialog.dismiss();

            }
        });


    }
    private void convertXMLtoPDF(View popupView){
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
            this.getDisplay().getRealMetrics(displayMetrics);
        }
        else this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        popupView.measure(View.MeasureSpec.makeMeasureSpec(displayMetrics.widthPixels,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(displayMetrics.heightPixels,View.MeasureSpec.EXACTLY));

        PdfDocument document = new PdfDocument();
        int viewWidth = popupView.getMeasuredWidth();
        int viewHeight = popupView.getMeasuredHeight();
        popupView.layout(8,8,displayMetrics.widthPixels,displayMetrics.heightPixels);
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(1080, 3600,1).create();
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        popupView.draw(canvas);
        document.finishPage(page);
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        String fileName = "report.pdf";
        File file = new File(downloadsDir, fileName);
        try{
            FileOutputStream fos = new FileOutputStream(file);
            document.writeTo(fos);
            document.close();
            Toast.makeText(this, "Export Success!", Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void askPermissions(){
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQUEST_CODE);
    }

    void storeDataInArrays(String grade) {
        Cursor cursor = DB.readAllDataByGrade(grade);
            while (cursor.moveToNext()) {
                NameLst.add(cursor.getString(1));
                PointsLst.add(Integer.parseInt(cursor.getString(7)));
            }
        }

    double getAverage() {
        Integer sum = 0;
        for (int i = 0; i < PointsLst.size(); i++) {
            sum += PointsLst.get(i);
        }
        double average = (double) sum / PointsLst.size();
        return average;
    }

    void clearArrays() {
        NameLst.clear();
        PointsLst.clear();
    }

    String getNameofHighestPoints() {
        return NameLst.get(PointsLst.indexOf(Collections.max(PointsLst)));
    }

    int getHighestPoints(){
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < PointsLst.size(); i++) {
            int value = PointsLst.get(i);
            if (value > max) {
                max = value;
            }
        }
        return max;
    }

    String getPrizes(int points) {
        String prizesOutput = "";
        for (String key : prizes.keySet()) {
            int val = prizes.get(key);
            if (val < points) {
                prizesOutput += key + ", ";
            }
        }
        if (prizesOutput.equals("")){
            return "Nothing";
        }
        return prizesOutput;

    }
}