package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter1 extends RecyclerView.Adapter<CustomAdapter1.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList namelst, gradelst, pointlst;
    CustomAdapter1(Context context, ArrayList namelst, ArrayList gradelst, ArrayList pointlst){
        this.context = context;
        this.namelst = namelst;
        this.gradelst = gradelst;
        this.pointlst = pointlst;

    }
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row1,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter1.MyViewHolder holder, int position) {
        holder.nameid.setText(String.valueOf(namelst.get(position)));
        holder.gradeid.setText(String.valueOf(gradelst.get(position)));
        holder.pointid.setText(String.valueOf(pointlst.get(position)));
    }

    @Override
    public int getItemCount() {
        return namelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nameid, gradeid, pointid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nameid = itemView.findViewById(R.id.nameid);
            gradeid = itemView.findViewById(R.id.gradeid);
            pointid = itemView.findViewById(R.id.pointsid);
        }

    }
    public void clear() {
        int size = namelst.size();
        namelst.clear();
        gradelst.clear();
        pointlst.clear();
        notifyItemRangeRemoved(0, size);
    }
}
