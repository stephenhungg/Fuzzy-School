package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewLeaderboard extends AppCompatActivity {
    DatabaseHelper DB;
    ArrayList<String> namelst, gradelst, pointlst;
    Switch togglesort;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_leaderboard);
        DB = new DatabaseHelper(this);
        togglesort = findViewById(R.id.togglesort);
        namelst = new ArrayList<>();
        gradelst = new ArrayList<>();
        pointlst = new ArrayList<>();
        storeDataInArrays(false);
        RecyclerView recyclerView = findViewById(R.id.RecyclerView);
        CustomAdapter1 customAdapter = new CustomAdapter1(ViewLeaderboard.this, namelst, gradelst, pointlst);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewLeaderboard.this));
        togglesort.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                customAdapter.clear();
                storeDataInArrays(b);
                RecyclerView recyclerView = findViewById(R.id.RecyclerView);
                CustomAdapter1 customAdapter = new CustomAdapter1(ViewLeaderboard.this, namelst, gradelst, pointlst);
                recyclerView.setAdapter(customAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(ViewLeaderboard.this));
            }
        });

    }
    void storeDataInArrays(Boolean switchState){
        Cursor cursor = null;
        if(switchState == true) {
            cursor = DB.readAllDataSortDecreasing();
        }
        else{
            cursor = DB.readAllDataSortGrade();
        }
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                namelst.add(cursor.getString(1));
                gradelst.add(cursor.getString(5));
                pointlst.add(cursor.getString(7));
            }
        }
    }
}