package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class CustomAdapter2 extends RecyclerView.Adapter<CustomAdapter2.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList datelst, namelst, typelst, durationlst;
    CustomAdapter2(Context context, ArrayList datelst, ArrayList namelst, ArrayList typelst, ArrayList durationlst){
        this.context = context;
        this.datelst = datelst;
        this.namelst = namelst;
        this.typelst = typelst;
        this.durationlst = durationlst;
    }
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row2,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter2.MyViewHolder holder, int position) {
        holder.dateid.setText(String.valueOf(datelst.get(position)));
        holder.nameid.setText(String.valueOf(namelst.get(position)));
        holder.typeid.setText(String.valueOf(typelst.get(position)));
        holder.durationid.setText(String.valueOf(durationlst.get(position)));
    }

    @Override
    public int getItemCount() {
        return namelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView dateid, nameid, typeid, durationid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dateid = itemView.findViewById(R.id.dateid);
            nameid = itemView.findViewById(R.id.nameid);
            typeid = itemView.findViewById(R.id.typeid);
            durationid = itemView.findViewById(R.id.durationid);

        }

    }
}
