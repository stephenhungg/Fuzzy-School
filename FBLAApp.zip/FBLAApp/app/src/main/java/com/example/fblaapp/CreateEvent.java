package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;

// This class extends AppCompatActivity and represents the activity for creating a new event.
public class CreateEvent extends AppCompatActivity {
    private EditText etSelectDate, etEventName, etEventDuration;
    private RadioGroup SportEventOrNoGroup;
    private Button createButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyyMMdd");
        setContentView(R.layout.activity_create_event);
        etSelectDate = findViewById(R.id.SelectDateId);
        etEventName = findViewById(R.id.EventNameId);
        etEventDuration = findViewById(R.id.EventDurationId);
        createButton = findViewById(R.id.CreateEventButtonId);
        etSelectDate.addTextChangedListener(loginTextWatcher);
        etEventName.addTextChangedListener(loginTextWatcher);
        etEventDuration.addTextChangedListener(loginTextWatcher);
        SportEventOrNoGroup = findViewById(R.id.SportEventOrNoGroup);
        DatabaseHelper DB = new DatabaseHelper(this);
        final Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        etSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dialog = new DatePickerDialog(CreateEvent.this, R.style.TimePickerTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        i1 = i1 + 1;
                        String date = ""+i + String.format("%02d", i1) + String.format("%02d", i2);

                        etSelectDate.setText(date);

                    }
                }, year, month, day);
                dialog.show();
            }
        });
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId = SportEventOrNoGroup.getCheckedRadioButtonId();
                RadioButton radioButton1 = findViewById(radioId);
                String sportornah = radioButton1.getText().toString();
                String EventName = etEventName.getText().toString();
                String EventDate = etSelectDate.getText().toString();
                String EventDuration = etEventDuration.getText().toString();
                Boolean checkinsertdata = DB.inserteventdata(EventName, EventDate, EventDuration, sportornah);
                if (checkinsertdata == true) {
                    Toast.makeText(CreateEvent.this, "Event Creation Successful", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CreateEvent.this, "Event Creation Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private TextWatcher loginTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String SelectDate = etSelectDate.getText().toString().trim();
            String EventName = etEventName.getText().toString().trim();
            String EventDuration = etEventDuration.getText().toString().trim();
            createButton.setEnabled(!SelectDate.isEmpty() && !EventName.isEmpty()&& !EventDuration.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }

    };
}

