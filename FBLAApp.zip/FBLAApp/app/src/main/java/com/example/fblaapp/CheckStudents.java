package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.sql.Array;
import java.util.ArrayList;

public class CheckStudents extends AppCompatActivity implements QuantityListener{
    RecyclerView recycler_view;
    QuantityAdapter adapter;
    DatabaseHelper DB;
    String code;
    Button confirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_students);//show the students to be checked
        DB = new DatabaseHelper(this);// initialize database
        confirm = findViewById(R.id.confirm); // initialize confirm button
        //get the username of the teacher and the hours of the event
        Bundle b = getIntent().getExtras();
        String user = b.getString("username");
        int hours = b.getInt("hours");
        //get respective code of the teacher
        String code = getCode(user);
        Log.d("the code is",code);
        //get students and store into an array to be used in the recyclerview
        storeDataInArraysStudents(code);
        recycler_view = findViewById(R.id.RecyclerView);
        // for each student that has been selected by the checkbox, add points to their number of points
        setRecyclerView();
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> students = adapter.getCheckedStudents();
                for(String student : students){
                    DB.updatePoints(student, hours*60);
                }
                //if it worked, show message
                Toast.makeText(CheckStudents.this, "Points Added Successfully", Toast.LENGTH_SHORT).show();
            }
        });

    }
    //method to store list of students into an ArrayList
    private ArrayList<String> storeDataInArraysStudents(String code){
        ArrayList<String> students = new ArrayList<>();
        Cursor cursor = DB.readAllData(code);
        while(cursor.moveToNext()){
            students.add(cursor.getString(1));
        }
        return students;
    }
    //method to fill the recyclerview
    private void setRecyclerView(){
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));
        adapter = new QuantityAdapter(this,storeDataInArraysStudents(code),this);
        recycler_view.setAdapter(adapter);
    }
    //method to get teacher's code
    @SuppressLint("Range")
    String getCode(String user) {
        Cursor cursor = DB.getCode(user);
        if (cursor != null && cursor.moveToFirst()) {
            code = cursor.getString(cursor.getColumnIndex("code"));
            cursor.close();
        }
        return code;
    }

    @Override
    public void onQuantityChange(ArrayList<String> students) {

    }
}