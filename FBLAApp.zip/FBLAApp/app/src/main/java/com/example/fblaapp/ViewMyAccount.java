package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ViewMyAccount extends AppCompatActivity {
    TextView FullName, Grade, Username, Password, Points;
    DatabaseHelper DB;
    Bundle b;
    Button toggle, EditAccount;
    Boolean showornah;
    public void Show(){
        Password.setVisibility(View.VISIBLE);
    }
    public void Hide(){
        Password.setVisibility(View.INVISIBLE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_account);
        showornah = false;
        toggle = findViewById(R.id.showNHideButton);
        EditAccount = findViewById(R.id.EditAccountInfo);
        FullName = findViewById(R.id.name);
        Grade = findViewById(R.id.Grade);
        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
        Points = findViewById(R.id.Points);
        b = getIntent().getExtras();
        String[] data = b.getStringArray("strings");
        DB = new DatabaseHelper(this);
        FullName.setText("Full Name: " +data[0]);
        Grade.setText("Grade: "+data[1]);
        Username.setText("Username: "+data[2]);
        Password.setText("Password: "+data[3]);
        Points.setText("Points in Current Quarter: "+data[4]);
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(showornah == false){
                    Show();
                    showornah = true;
                }
                else{
                    Hide();
                    showornah = false;
                }

            }
        });
        EditAccount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent EditAccountInfo = new Intent(ViewMyAccount.this,EditAccount.class);
                Bundle b = new Bundle();
                b.putString("name",data[0]);
                EditAccountInfo.putExtras(b);
                startActivity(EditAccountInfo);
            }
        });


    }
}