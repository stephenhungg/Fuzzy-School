package com.example.fblaapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context) {
        super(context, "database", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create Table EventData(name TEXT, date TEXT, duration TEXT, type TEXT)");
        sqLiteDatabase.execSQL("create Table UserData2(email TEXT, name TEXT, username TEXT, password TEXT, role TEXT, grade TEXT, code TEXT, points TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop Table if exists EventData");
        sqLiteDatabase.execSQL("drop Table if exists UserData2");
    }

    public Boolean insertuserdata(String email, String name, String username, String password, String role, String grade, String code, String points) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("name", name);
        String encryptedPassword = PasswordUtils.encryptPassword(password);
        contentValues.put("username", username);
        contentValues.put("password", encryptedPassword);
        contentValues.put("role", role);
        contentValues.put("grade", grade);
        contentValues.put("code", code);
        contentValues.put("points", points);
        long result = DB.insert("UserData2", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean inserteventdata(String name, String date, String duration, String type) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("date", date);
        contentValues.put("duration", duration);
        contentValues.put("type", type);
        long result = DB.insert("EventData", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public void deleteUser(String name){
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.delete("UserData2","name=?",new String[]{name});
    }

    public void clearDatabase(String TABLE_NAME) {
        SQLiteDatabase DB = this.getWritableDatabase();
        String clearDBQuery = "DELETE FROM " + TABLE_NAME;
        DB.execSQL(clearDBQuery);
    }

    public Boolean checkusernamepassword(String username, String password, String role) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("select * from UserData2 where username=? and password=? and role=?", new String[]{username, password, role});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public String getDataName(String username) {
        String response = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from UserData2 where username = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            do {
                String email = cursor.getString(0);
                String name = cursor.getString(1);
                String grade = cursor.getString(5);
                String code = cursor.getString(6);
                // Do something with the retrieved data
                response += name + " " + code;
            } while (cursor.moveToNext());
        }
        return response;
    }

    Cursor getDataNameAll(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM UserData2 WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{username});
        }
        return cursor;
    }

    Cursor readAllData(String code) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM UserData2 WHERE code = ? AND role != 'Teacher' ORDER BY name ASC ";
        Cursor cursor = db.rawQuery(query, new String[]{code});
        return cursor;
    }

    Cursor readAllDataSortDecreasing() {
        String query = "SELECT * FROM UserData2 WHERE role != 'Teacher' ORDER BY CAST(points AS INTEGER) DESC";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    Cursor readAllDataSortGrade() {
        String query = "SELECT * FROM UserData2 WHERE role != 'Teacher' ORDER BY CAST(grade AS INTEGER) DESC, name ASC";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    Cursor readAllDataAfterTodaysDate(String currentDate) {
        String query = "SELECT * FROM EventData WHERE date > '" + currentDate + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    Cursor readAllDataBeforeTodaysDate(String currentDate) {
        String query = "SELECT * FROM EventData WHERE date <= '" + currentDate + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    Cursor readAllDataByGrade(String grade) {
        String query = "SELECT * FROM UserData2 WHERE grade=?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{grade});
        }
        return cursor;
    }

    Cursor getCode(String username) {
        String query = "SELECT code FROM UserData2 WHERE username = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{username});
        }
        return cursor;
    }
    Cursor getPassword(String username) {
        String query = "SELECT password FROM UserData2 WHERE username = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{username});
        }
        return cursor;
    }
    Cursor getRole(String username) {
        String query = "SELECT role FROM UserData2 WHERE username = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{username});
        }
        return cursor;
    }

    void updatePoints(String name, int points) {
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("points", "points + " + points);
        db.execSQL("UPDATE UserData2 SET points = points + ? WHERE name=?", new String[]{Integer.toString(points), name});
    }

    @SuppressLint("Range")
    int getEventHours(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        int hours = 0;
        if (db != null) {
            Cursor cursor = db.rawQuery("SELECT duration FROM EventData WHERE name = ?", new String[]{name});
            if (cursor.moveToFirst()) {
                hours = cursor.getInt(cursor.getColumnIndex("duration"));
            }
            cursor.close();
            db.close();
        }
        return hours;
    }

    public void editUserData(String oldName, String newName, String grade, String username, String password, String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", newName);
        contentValues.put("grade", grade);
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("code", code);
        db.update("UserData2", contentValues, "name=?", new String[]{oldName});
        db.close();
    }
    public Boolean userExists(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM UserData2 WHERE username = ?", new String[]{username});
        boolean usernameExists = (cursor != null && cursor.getCount() > 0);
        if(cursor!=null){
            cursor.close();
        }
        return usernameExists;
    }
}
