package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class TeacherLoginPage extends AppCompatActivity {
    EditText username, password;
    Button login, signup;
    DatabaseHelper DB;
    String userPass, userRole;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_login_page);
        username = findViewById(R.id.UsernameLogin);
        password = findViewById(R.id.PasswordLogin);
        login = findViewById(R.id.LoginButton);
        signup = findViewById(R.id.SignUpButton);
        DB = new DatabaseHelper(this);
        username.addTextChangedListener(loginTextWatcher);
        password.addTextChangedListener(loginTextWatcher);
        login.setOnClickListener(new View.OnClickListener(){
            @SuppressLint("Range")
            @Override
            public void onClick(View v) {
                String checkUsername = username.getText().toString();
                String checkPassword = password.getText().toString();
                if (DB.userExists(checkUsername) == true) {
                    Cursor getPassCursor = DB.getPassword(checkUsername);
                    Cursor getRoleCursor = DB.getRole(checkUsername);
                    getRoleCursor.moveToFirst();
                    getPassCursor.moveToFirst();
                    if (getPassCursor.moveToFirst()) {
                        userPass = getPassCursor.getString(getPassCursor.getColumnIndex("password"));
                    }
                    if (getRoleCursor.moveToFirst()) {
                        userRole = getRoleCursor.getString(getRoleCursor.getColumnIndex("role"));
                    }
                    boolean isPasswordMatched = PasswordUtils.verifyPassword(checkPassword, userPass) && userRole.equals("Teacher");
                    if (isPasswordMatched) {
                        Toast.makeText(TeacherLoginPage.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), TeacherHome.class);
                        Bundle b = new Bundle();
                        b.putString("username", checkUsername);
                        intent.putExtras(b);
                        startActivity(intent);
                    } else {
                        Toast.makeText(TeacherLoginPage.this, "Login Failed", Toast.LENGTH_SHORT).show();
                    }

                }
                else{
                    Toast.makeText(TeacherLoginPage.this,"Login Failed",Toast.LENGTH_SHORT).show();
                }
            }
        });
        signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent CreateAccPage = new Intent(TeacherLoginPage.this, CreateAccPage.class);
                startActivity(CreateAccPage);
            }
        });


    }
    private TextWatcher loginTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String emailAddInput = username.getText().toString().trim();
            String nameInput = password.getText().toString().trim();
            login.setEnabled(!emailAddInput.isEmpty() && !nameInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }

    };
}