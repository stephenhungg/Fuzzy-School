package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.ArrayList;

public class ViewAttendance extends AppCompatActivity {
    LinearLayout spinnerContainer;
    private CustomAdapter4.RecyclerViewClickListener listener;

    ArrayList<String> pastEvents, students;
    DatabaseHelper DB = new DatabaseHelper(this);
    String code;
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

    // Get the current date as a Date object
    Date currentDate = new Date();

    // Format the current date as a string in the desired format
    String dateString = dateFormat.format(currentDate);
    Bundle b;
    CustomAdapter4 customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance);
        spinnerContainer = findViewById(R.id.spinnerContainer);
        pastEvents = new ArrayList<String>();
        storeDataInArrays();
        b = getIntent().getExtras();

        students = new ArrayList<String>();
        setOnClickListener();
        RecyclerView recyclerView = findViewById(R.id.RecyclerView);
        customAdapter = new CustomAdapter4(ViewAttendance.this, pastEvents, listener);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewAttendance.this));


    }

    private void setOnClickListener() {
        listener = new CustomAdapter4.RecyclerViewClickListener() {
            @Override
            public void onClick(View v, int position) {
                Intent intent = new Intent(ViewAttendance.this, CheckStudents.class);
                b.putInt("hours",DB.getEventHours(customAdapter.getSelectedEventName()));
                intent.putExtras(b);
                startActivity(intent);
            }
        };
    }

    void storeDataInArrays() {
        Cursor cursor = DB.readAllDataBeforeTodaysDate("20230625");
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                pastEvents.add(cursor.getString(0));
            }
        }
    }



}