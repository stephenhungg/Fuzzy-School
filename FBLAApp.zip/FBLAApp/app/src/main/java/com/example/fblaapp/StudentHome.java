package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class StudentHome extends AppCompatActivity {
    Button ViewPrizes, ViewLeaderboard, ViewMyAccount, ViewEvents, signOut, helpButton;
    TextView tv1;
    DatabaseHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_home);
        ViewPrizes = findViewById(R.id.ViewPrizes);
        ViewLeaderboard = findViewById(R.id.ViewLeaderboard);
        ViewMyAccount = findViewById(R.id.ViewMyAccount);
        signOut = findViewById(R.id.SignOut);
        helpButton = findViewById(R.id.helpButton);
        DB = new DatabaseHelper(this);
        ViewEvents = findViewById(R.id.ViewEvents);
        Bundle b = getIntent().getExtras();
        String username = b.getString("username");
        tv1 = findViewById(R.id.TV1);
        String name = DB.getDataName(username);
        tv1.setText("Hi " + name.split("\\s+")[0] + "!👋");
        ViewPrizes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewPrize = new Intent(StudentHome.this, ViewPrizes.class);
                startActivity(viewPrize);
            }
        });
        ViewLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewLeaderboard = new Intent(StudentHome.this, ViewLeaderboard.class);
                startActivity(viewLeaderboard);
            }
        });
        ViewMyAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewMyAccount = new Intent(StudentHome.this, ViewMyAccount.class);
                b.putStringArray("strings", getUserData(username));
                viewMyAccount.putExtras(b);
                startActivity(viewMyAccount);
            }
        });
        ViewEvents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewEvents = new Intent(StudentHome.this, ViewEvents.class);
                startActivity(viewEvents);
            }
        });
        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainPage = new Intent(StudentHome.this, MainActivity.class);
                startActivity(mainPage);
            }
        });
        helpButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent helpMenu = new Intent(StudentHome.this, Help.class);
                startActivity(helpMenu);
            }
        });

    }

    public String[] getUserData(String username) {
        Cursor cursor = DB.getDataNameAll(username);
        if (cursor.moveToFirst()) {
            String name = cursor.getString(1);
            String grade = cursor.getString(5);
            String Username = cursor.getString(2);
            String password = cursor.getString(3);
            String points = cursor.getString(7);

            String[] userDataStrings = {name, grade, Username, password, points};
            return userDataStrings;
        } else {
            return new String[0];
        }
    }
}