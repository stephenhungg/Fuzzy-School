package com.example.fblaapp;
import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtils {

    // Define the strength of the encryption (the number of hashing rounds)
    private static final int PASSWORD_STRENGTH = 12;

    // Encrypts the provided password
    public static String encryptPassword(String password) {
        String salt = BCrypt.gensalt(PASSWORD_STRENGTH);
        return BCrypt.hashpw(password, salt);
    }

    // Verifies if the provided password matches the encrypted password
    public static boolean verifyPassword(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }
}
