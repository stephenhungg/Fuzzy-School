package com.example.fblaapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class QuantityAdapter extends RecyclerView.Adapter<QuantityAdapter.ViewHolder> {
    View view;
    Context context;
    ArrayList<String> students;
    ArrayList<String> students_0 = new ArrayList<>();
    QuantityListener quantityListener;
    public QuantityAdapter(Context context, ArrayList<String> students, QuantityListener quantityListener){
        this.context = context;
        this.students = students;
        this.quantityListener = quantityListener;
    }
    public QuantityAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(context).inflate(R.layout.check_layout,parent,false);
        return new ViewHolder(view);
    }
    public View getView(){
        return view;
    }

    @Override
    public void onBindViewHolder(@NonNull QuantityAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if(students != null && students.size() > 0){
            holder.check_box.setText(students.get(position));
            holder.check_box.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        if(holder.check_box.isChecked()){
                            students_0.add(students.get(position));
                        } else {
                            students_0.remove(students.get(position));
                        }
                        quantityListener.onQuantityChange(students_0);
                    }
            });
        }
    }

    @Override
    public int getItemCount() {
        return students.size();
    }
    public ArrayList getCheckedStudents(){
        return students_0;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox check_box;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            check_box = itemView.findViewById(R.id.checkBox);
        }
    }
}
