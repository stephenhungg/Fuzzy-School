package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ViewEvents extends AppCompatActivity {
    DatabaseHelper DB;
    final Calendar calendar = Calendar.getInstance();
    final int year = calendar.get(Calendar.YEAR);
    final int month = calendar.get(Calendar.MONTH);
    final int day = calendar.get(Calendar.DAY_OF_MONTH);
    Date currentDate = new Date();
    // Define the input date format
    SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyyMMdd");

    // Define the output date format
    SimpleDateFormat outputDateFormat = new SimpleDateFormat("MM/dd/yyyy");
    // Define the format of the date string
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

    // Convert the date to the desired format
    String dateString = dateFormat.format(currentDate);
    ArrayList<String> datelst, namelst, typelst, durationlst, date1lst, name1lst, type1lst, duration1lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_events);
        DB = new DatabaseHelper(this);
        datelst = new ArrayList<>();
        namelst = new ArrayList<>();
        typelst = new ArrayList<>();
        durationlst = new ArrayList<>();
        date1lst = new ArrayList<>();
        name1lst = new ArrayList<>();
        type1lst = new ArrayList<>();
        duration1lst = new ArrayList<>();
        storeDataInArrays1();
        for (int i = 0; i < datelst.size(); i++) {
            String dateStr = datelst.get(i);
            Date date = null;
            try {
                date = inputDateFormat.parse(dateStr);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            dateStr = outputDateFormat.format(date);
            datelst.set(i, dateStr);
        }
        storeDataInArrays2();
        for (int i = 0; i < date1lst.size(); i++) {
            String dateStr = date1lst.get(i);
            Date date = null;
            try {
                date = inputDateFormat.parse(dateStr);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            dateStr = outputDateFormat.format(date);
            date1lst.set(i, dateStr);
        }
        RecyclerView recyclerView = findViewById(R.id.RecyclerView);
        CustomAdapter2 customAdapter = new CustomAdapter2(ViewEvents.this, datelst, namelst, typelst, durationlst);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewEvents.this));
        RecyclerView recyclerView1 = findViewById(R.id.recyclerview1);
        CustomAdapter3 customAdapter1 = new CustomAdapter3(ViewEvents.this, date1lst, name1lst, type1lst, duration1lst);
        recyclerView1.setAdapter(customAdapter1);
        recyclerView1.setLayoutManager(new LinearLayoutManager(ViewEvents.this));

    }
    void storeDataInArrays2(){
        Cursor cursor = DB.readAllDataAfterTodaysDate(dateString);

        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                date1lst.add(cursor.getString(1));
                name1lst.add(cursor.getString(0));
                type1lst.add(cursor.getString(3));
                duration1lst.add(cursor.getString(2));
            }
        }
    }
    void storeDataInArrays1(){
        Cursor cursor = DB.readAllDataBeforeTodaysDate(dateString);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                datelst.add(cursor.getString(1));
                namelst.add(cursor.getString(0));
                typelst.add(cursor.getString(3));
                durationlst.add(cursor.getString(2));
            }
        }
    }
}